/** Automatically generated file. DO NOT MODIFY */
package com.pluralsight.demoapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}